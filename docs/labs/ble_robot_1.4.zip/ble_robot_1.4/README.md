# ble_robot
The Python and Arduino packages provide you with the base code necessary to help you communicate between your computer and the Artemis board through BLE. You will use them to setup an initial communication channel in this lab, and work towards a more comprehensive robot control protocol in your future lab sessions.


Updates from 1.3: further modifications to base_ble.py for windows machines. Confirmed functionality on windows, mac OS (1/8/26).
