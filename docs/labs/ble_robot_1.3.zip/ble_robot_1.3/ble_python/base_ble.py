import asyncio
import time
import bleach
from bleak import BleakClient, BleakScanner, BleakError
import nest_asyncio
import struct
import yaml
import sys
import platform

# If macOS >=12.0
OS_PLATFORM = platform.system()
IS_ATLEAST_MAC_OS_12 = False
if OS_PLATFORM == 'Darwin':
    import objc
    IS_ATLEAST_MAC_OS_12 = objc.macos_available(12,0)

from utils import setup_logging
LOG = setup_logging("ble.log")

# Ref: https://stackoverflow.com/questions/31875/is-there-a-simple-elegant-way-to-define-singletons    
def wait_a(coroutine):
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coroutine)

def wait_b(coroutine):
    return asyncio.run(coroutine)

# Ref: https://github.com/alexandrebarachant/muse-lsl/pull/148/files
class BLEAsyncDevice():
    def __init__(self, address, service_uuid):
        nest_asyncio.apply()

        self.set_address(address, service_uuid)
        
        self.client = None
        self.error_msg = None

    def set_address(self, address, service_uuid):
        self.address = address
        self.service_uuid = service_uuid

    def disconnect_handler(self, data):
        LOG.info("Disconnected from {}".format(data.address))
    
    def _is_atleast_mac_os_12(self):
        return IS_ATLEAST_MAC_OS_12
    
    def _get_platform(self):
        return OS_PLATFORM
    
    async def _get_ble_device(self, timeout=10.0):
        if OS_PLATFORM == "Windows" or OS_PLATFORM == "Linux":
            found_device = None
            scanner = BleakScanner()
        
            LOG.info(f"Scanning for device {self.address} with service {self.service_uuid}")
        
            async def detection_callback(dev, advertisement_data):
                nonlocal found_device
                LOG.debug(f"Found: {dev.address}, services: {advertisement_data.service_uuids}")
            
                if dev.address.upper() == self.address.upper():
                    LOG.info(f"Found matching address: {dev.address}")
                    if self.service_uuid in advertisement_data.service_uuids:
                        LOG.info(f"Service UUID matches!")
                        found_device = dev
                        await scanner.stop()
        
            scanner.register_detection_callback(detection_callback)
            await scanner.start()
            await asyncio.sleep(timeout)
        
            try:
                await scanner.stop()
            except:
                pass
            
            if found_device is None:
                raise Exception(f'Could not find device with address: {self.address} and service uuid: {self.service_uuid}')
        
            return found_device
        
        else:  # macOS - cannot use MAC address, must use service UUID
            LOG.info(f"Scanning for device with service UUID: {self.service_uuid}")
        
            found_device = None
        
            # Scan for devices advertising the specific service UUID
            devices = await BleakScanner.discover(timeout=timeout, service_uuids=[self.service_uuid])
        
            LOG.info(f"Found {len(devices)} device(s) advertising service {self.service_uuid}")
        
            if len(devices) > 0:
                found_device = devices[0]
                LOG.info(f"Selecting device: {found_device.address} (name: {found_device.name})")
        
            if found_device is None:
                raise Exception(f'Could not find device advertising service uuid: {self.service_uuid}')
        
            return found_device


    async def _connect(self):
        if self.client and self.client.is_connected:
            LOG.info("Already connected to a BLE device")
            return True
        else:
            LOG.info('Looking for Artemis Nano Peripheral Device: {}'.format(self.address))
            success = False
            device = await self._get_ble_device()
            self.client = BleakClient(device)
            try:
                await self.client.connect()
                success = True
            except Exception as e:
                self.error_msg = str(e)
                LOG.error(e)

            if self.client.is_connected:
                self.client.disconnected_callback = self.disconnect_handler
                LOG.info("Connected to {}".format(self.address))
            
            return success
    
    async def _disconnect(self):
        if self.client and self.client.is_connected:
            await self.client.disconnect()
        else:
            raise Exception("Not connected to a BLE device")

    async def _write(self, uuid, byte_array):
        if self.client and self.client.is_connected:
            await self.client.write_gatt_char(uuid, byte_array,response=True)
        else:
            raise Exception("Not connected to a BLE device")

    async def _read(self, uuid):
        if self.client and self.client.is_connected:
            return await self.client.read_gatt_char(uuid)
        else:
            raise Exception("Not connected to a BLE device")

    async def _start_notify(self, uuid, notification_handler):
        if self.client and self.client.is_connected:
            await self.client.start_notify(uuid, notification_handler)
        else:
            raise Exception("Not connected to a BLE device")

    async def _stop_notify(self, uuid):
        if self.client and self.client.is_connected:
            await self.client.stop_notify(uuid)
        else:
            raise Exception("Not connected to a BLE device")

# Ref: https://github.com/hbldh/bleak/blob/develop/examples/service_explorer.py
    async def _explore_services(self):
        LOG.info(f"Connected to: {self.client.is_connected}")

        for service in self.client.services:
            LOG.info(f"[Service] {service}")
            for char in service.characteristics:
                if "read" in char.properties:
                    try:
                        value = bytes(await self.client.read_gatt_char(char.uuid))
                        LOG.info(
                            f"\t[Characteristic] {char} ({','.join(char.properties)}), Value: {value}"
                        )
                    except Exception as e:
                        LOG.error(
                            f"\t[Characteristic] {char} ({','.join(char.properties)}), Value: {e}"
                        )

                else:
                    value = None
                    LOG.info(
                        f"\t[Characteristic] {char} ({','.join(char.properties)}), Value: {value}"
                    )

                for descriptor in char.descriptors:
                    try:
                        value = bytes(
                            await self.client.read_gatt_descriptor(descriptor.handle)
                        )
                        LOG.info(f"\t\t[Descriptor] {descriptor}) | Value: {value}")
                    except Exception as e:
                        LOG.error(f"\t\t[Descriptor] {descriptor}) | Value: {e}")
